Name: Vu Minh Anh Le
Section: 12117
UFL email: vu.le@ufl.edu
System: Windows
Compiler: MingW64
SFML version: SFML-2.6.1
IDE: CLion
Other notes: None